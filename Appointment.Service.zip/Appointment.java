
public class Appointment {

}
