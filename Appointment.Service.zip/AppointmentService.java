
public class AppointmentService {

}
