
public class AppointmentServiceTest {

}
