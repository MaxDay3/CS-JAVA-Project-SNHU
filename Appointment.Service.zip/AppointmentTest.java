
public class AppointmentTest {

}
