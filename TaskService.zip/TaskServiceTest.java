import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;
import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class TaskServiceTest {
    public static void main(String[] Args) {
        Result result = JUnitCore.runClasses(TaskTest.class);

        
        for(Failure fail: result.getFailures()) {
            System.out.println(fail);
        }

        if(result.wasSuccessful()) {
            System.out.println("TaskServiceTest - all tests passed");
        } else {
            System.out.println("TaskService - some tests failed");
        }
    }

    
    private final String ID1 = "2468";
    private final String Name1 = "Daring Man";
    private final String Description1 = "Buy Eggs";
    private final Task task1 = new Task(ID1, Name1, Description1);

    private TaskService service = new TaskService(task1);

    @Test
    public void testConstructor() {
        System.out.println("TaskService Constructor tests");

        System.out.printf("\tFixed constructor should have the following task: %s\n", task1);
        assertEquals(task1, service.getTask(task1));

        System.out.println("\tConstructor with no fields should have size 0");
        TaskService service2 = new TaskService();
        assertEquals(service2.getSize(), 0);
    }

    @Test
    public void testInsertion() {
        System.out.println("TaskService Insertion tests");

        Task task2 = new Task("746321", "Add Me", "Try to insert a new task");
        System.out.printf("\tTry to a non-existing task: %s\n", task2);
        assertEquals(true, service.addTask(task2));
        assertEquals(task2, service.getTask(task2));

        System.out.println("\tTry to add an existing task - expect a boolean false response");
        assertEquals(false, service.addTask(task1));
    }

    @Test
    public void testUpdate() {
        System.out.println("TaskService Update tests");
        Task task3 = new Task(task1.getId(), "Update Me", "Updated name and description of my task object");

        System.out.println("\tTry to update an existing task");
        assertEquals(true, service.updateTask(task3));
        assertEquals(task3, service.getTask(task3));

        System.out.println("\tTry to update a nonexisting task - expect a boolean false response");
        assertEquals(false, service.updateTask(new Task("111111", "Not here", "This task doesn't exist")));
    }

    @Test
    public void testRemove() {
        System.out.println("TaskService Remove tests");
        Task task4 = new Task("7777", "Temp Task", "This is a temporary task for testRemove");

        System.out.println("\tInsert and make sure that we can remove our task");
        service.addTask(task4);
        assertEquals(true, service.removeTask(task4));

        System.out.println("\tTry to remove a nonexisting task - expect a boolean false response");
        assertEquals(false, service.removeTask(task4));
    }
}
